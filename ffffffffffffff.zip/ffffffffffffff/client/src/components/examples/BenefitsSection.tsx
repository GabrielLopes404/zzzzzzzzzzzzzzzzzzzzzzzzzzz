import BenefitsSection from '../BenefitsSection';

export default function BenefitsSectionExample() {
  return <BenefitsSection />;
}
