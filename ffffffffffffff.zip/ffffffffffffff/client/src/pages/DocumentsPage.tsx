import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Upload, FileText, Image, File, Download, Search, Eye, Trash2, MoreHorizontal, FolderOpen } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: { type: "spring", stiffness: 100 }
  }
};

export default function DocumentsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState("all");

  const documents = [
    { id: 1, name: "Contrato de Serviços - Cliente ABC.pdf", type: "pdf", size: "2.5 MB", category: "Contratos", uploadDate: "2025-11-08", tags: ["contrato", "cliente"] },
    { id: 2, name: "Nota Fiscal 12345.pdf", type: "pdf", size: "450 KB", category: "Notas Fiscais", uploadDate: "2025-11-07", tags: ["nota fiscal", "pagamento"] },
    { id: 3, name: "Comprovante Pagamento Fornecedor.jpg", type: "image", size: "1.2 MB", category: "Comprovantes", uploadDate: "2025-11-06", tags: ["pagamento", "fornecedor"] },
    { id: 4, name: "Relatório Mensal Outubro.xlsx", type: "excel", size: "3.1 MB", category: "Relatórios", uploadDate: "2025-11-05", tags: ["relatório", "mensal"] },
    { id: 5, name: "Proposta Comercial Cliente XYZ.docx", type: "word", size: "890 KB", category: "Propostas", uploadDate: "2025-11-04", tags: ["proposta", "cliente"] },
  ];

  const getFileIcon = (type: string) => {
    switch (type) {
      case "pdf": return FileText;
      case "image": return Image;
      default: return File;
    }
  };

  const filteredDocuments = documents.filter(d => {
    const matchesSearch = d.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         d.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === "all" || d.type === filterType;
    return matchesSearch && matchesType;
  });

  return (
    <AppLayout>
      <motion.div 
        className="space-y-6"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div variants={itemVariants} className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              Documentos
            </h1>
            <p className="text-muted-foreground mt-1">
              Centralize e organize todos os seus documentos importantes
            </p>
          </div>
          <Button className="gap-2 shadow-lg shadow-primary/20">
            <Upload className="h-4 w-4" />
            Upload de Documentos
          </Button>
        </motion.div>

        <motion.div variants={itemVariants} className="grid gap-6 md:grid-cols-4">
          <Card className="border-l-4 border-l-blue-500">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total de Documentos</p>
                  <p className="text-2xl font-bold mt-2">{documents.length}</p>
                </div>
                <FolderOpen className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-green-500">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">PDFs</p>
                  <p className="text-2xl font-bold mt-2">{documents.filter(d => d.type === "pdf").length}</p>
                </div>
                <FileText className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-purple-500">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Imagens</p>
                  <p className="text-2xl font-bold mt-2">{documents.filter(d => d.type === "image").length}</p>
                </div>
                <Image className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-orange-500">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Outros</p>
                  <p className="text-2xl font-bold mt-2">{documents.filter(d => d.type !== "pdf" && d.type !== "image").length}</p>
                </div>
                <File className="h-8 w-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
                <CardTitle>Todos os Documentos</CardTitle>
                <div className="flex flex-wrap gap-2 w-full sm:w-auto">
                  <div className="relative flex-1 sm:flex-initial sm:w-[240px]">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Buscar documentos..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-9"
                    />
                  </div>
                  
                  <Select value={filterType} onValueChange={setFilterType}>
                    <SelectTrigger className="w-[150px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos os tipos</SelectItem>
                      <SelectItem value="pdf">PDFs</SelectItem>
                      <SelectItem value="image">Imagens</SelectItem>
                      <SelectItem value="excel">Excel</SelectItem>
                      <SelectItem value="word">Word</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                <AnimatePresence>
                  {filteredDocuments.map((doc) => {
                    const Icon = getFileIcon(doc.type);
                    return (
                      <motion.div
                        key={doc.id}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.9 }}
                      >
                        <Card className="hover:shadow-lg transition-shadow">
                          <CardContent className="pt-6">
                            <div className="flex items-start justify-between mb-3">
                              <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center">
                                <Icon className="h-6 w-6 text-primary" />
                              </div>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="sm">
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem>
                                    <Eye className="h-4 w-4 mr-2" />
                                    Visualizar
                                  </DropdownMenuItem>
                                  <DropdownMenuItem>
                                    <Download className="h-4 w-4 mr-2" />
                                    Download
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem className="text-red-600">
                                    <Trash2 className="h-4 w-4 mr-2" />
                                    Excluir
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>

                            <h3 className="font-semibold text-sm mb-2 line-clamp-2">{doc.name}</h3>
                            
                            <div className="space-y-2">
                              <div className="flex items-center justify-between text-sm">
                                <Badge variant="outline">{doc.category}</Badge>
                                <span className="text-muted-foreground">{doc.size}</span>
                              </div>
                              
                              <p className="text-xs text-muted-foreground">
                                Enviado em {doc.uploadDate}
                              </p>

                              <div className="flex flex-wrap gap-1 mt-2">
                                {doc.tags.map((tag, index) => (
                                  <Badge key={index} variant="secondary" className="text-xs">
                                    {tag}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>

              {filteredDocuments.length === 0 && (
                <div className="text-center py-12">
                  <FolderOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">Nenhum documento encontrado</p>
                  <Button className="mt-4 gap-2">
                    <Upload className="h-4 w-4" />
                    Fazer primeiro upload
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="border-2 border-dashed hover:border-primary transition-colors cursor-pointer">
            <CardContent className="pt-6">
              <div className="flex flex-col items-center justify-center py-12">
                <Upload className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">Arraste arquivos para fazer upload</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  ou clique para selecionar arquivos do seu computador
                </p>
                <Button>Selecionar Arquivos</Button>
                <p className="text-xs text-muted-foreground mt-4">
                  Formatos suportados: PDF, JPEG, PNG, DOCX, XLSX (máx. 10MB)
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </AppLayout>
  );
}
