import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileSpreadsheet, Upload, FileText, Users } from "lucide-react";

export default function ImportsPage() {
  const importTypes = [
    {
      icon: FileSpreadsheet,
      title: "Importação padrão",
      description: "Importação de dados simples, utilizando o nosso formato",
      badge: null,
    },
    {
      icon: FileText,
      title: "Zero Paper",
      description: "Importação de dados utilizando o Excel do Zero Paper",
      badge: null,
    },
    {
      icon: Users,
      title: "Contatos",
      description: "Importação de contatos, utilizando o Excel",
      badge: null,
    },
    {
      icon: FileSpreadsheet,
      title: "OFX",
      description: "Importação de dados utilizando o formato de arquivo OFX",
      badge: null,
    },
  ];

  return (
    <AppLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Importações</h1>
          <p className="text-muted-foreground">
            Importe dados de diferentes fontes
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {importTypes.map((type, index) => {
            const Icon = type.icon;
            return (
              <Card 
                key={index}
                className="hover:shadow-lg transition-shadow cursor-pointer group"
              >
                <CardHeader>
                  <div className="flex items-start gap-4">
                    <div className="p-3 rounded-lg bg-primary/10 group-hover:bg-primary/20 transition-colors">
                      <Icon className="h-8 w-8 text-primary" />
                    </div>
                    <div className="flex-1">
                      <CardTitle className="flex items-center gap-2 text-lg">
                        {type.title}
                        {type.badge && (
                          <Badge variant="secondary">{type.badge}</Badge>
                        )}
                      </CardTitle>
                      <p className="text-sm text-muted-foreground mt-2">
                        {type.description}
                      </p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <Button className="w-full gap-2">
                    <Upload className="h-4 w-4" />
                    Importar
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Histórico de Importações</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center py-12">
              <p className="text-muted-foreground">Nenhuma importação realizada ainda</p>
              <p className="text-sm text-muted-foreground mt-2">
                Importar arquivo externo
              </p>
              <p className="text-sm text-muted-foreground">
                Clique em uma das opções acima para realizar a primeira importação
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
