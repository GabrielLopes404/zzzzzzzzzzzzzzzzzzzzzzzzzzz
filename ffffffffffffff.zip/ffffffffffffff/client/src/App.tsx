import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import LandingPage from "@/pages/LandingPage";
import LoginPage from "@/pages/LoginPage";
import RegisterPage from "@/pages/RegisterPage";
import DashboardPage from "@/pages/DashboardPage";
import CustomersPage from "@/pages/CustomersPage";
import InvoicesPage from "@/pages/InvoicesPage";
import SettingsPage from "@/pages/SettingsPage";
import TransactionsPage from "@/pages/TransactionsPage";
import ReportsPage from "@/pages/ReportsPage";
import ImportsPage from "@/pages/ImportsPage";
import ReconciliationsPage from "@/pages/ReconciliationsPage";
import ProfilePage from "@/pages/ProfilePage";
import AccountsPage from "@/pages/AccountsPage";
import CategoriesPage from "@/pages/CategoriesPage";
import CostCentersPage from "@/pages/CostCentersPage";
import BankAccountsPage from "@/pages/BankAccountsPage";
import DocumentsPage from "@/pages/DocumentsPage";
import TagsPage from "@/pages/TagsPage";
import ExportPage from "@/pages/ExportPage";
import SubscriptionPage from "@/pages/SubscriptionPage";
import PricingPage from "@/pages/PricingPage";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={LandingPage} />
      <Route path="/login" component={LoginPage} />
      <Route path="/register" component={RegisterPage} />
      <Route path="/app/dashboard" component={DashboardPage} />
      <Route path="/app/transactions" component={TransactionsPage} />
      <Route path="/app/customers" component={CustomersPage} />
      <Route path="/app/reports" component={ReportsPage} />
      <Route path="/app/imports" component={ImportsPage} />
      <Route path="/app/reconciliations" component={ReconciliationsPage} />
      <Route path="/app/invoices" component={InvoicesPage} />
      <Route path="/app/settings" component={SettingsPage} />
      <Route path="/app/profile" component={ProfilePage} />
      <Route path="/app/accounts" component={AccountsPage} />
      <Route path="/app/categories" component={CategoriesPage} />
      <Route path="/app/cost-centers" component={CostCentersPage} />
      <Route path="/app/bank-accounts" component={BankAccountsPage} />
      <Route path="/app/documents" component={DocumentsPage} />
      <Route path="/app/tags" component={TagsPage} />
      <Route path="/app/export" component={ExportPage} />
      <Route path="/app/subscription" component={SubscriptionPage} />
      <Route path="/app/pricing" component={PricingPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
