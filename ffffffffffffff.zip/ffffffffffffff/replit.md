# LUCREI - Sistema de Gestão Financeira SaaS

## Visão Geral
O LUCREI é um sistema completo de gestão financeira e clientes desenvolvido para pequenas e médias empresas. Permite gerenciar organizações, clientes, faturas e acompanhar métricas financeiras em tempo real.

## Estado Atual do Projeto (Novembro 2025)

### ✅ Backend Implementado
- **Schema de Banco de Dados Completo** (PostgreSQL + Drizzle ORM):
  - Organizations (organizações)
  - Users (usuários com roles: OWNER, ADMIN, CUSTOMER)
  - Customers (clientes)
  - Invoices (faturas)
  - Subscriptions (assinaturas Stripe)
  - Activities (logs de atividades)

- **API REST Completa**:
  - Autenticação (registro, login, logout) com Passport.js + bcrypt
  - CRUD de Organizações
  - CRUD de Clientes
  - CRUD de Faturas
  - Sistema de Métricas (totalCustomers, totalInvoices, totalRevenue, etc)
  - Logs de Atividades

- **Segurança**:
  - Autenticação baseada em sessão (express-session)
  - Hash de senhas com bcrypt
  - Middleware de autenticação e autorização
  - Validação de dados com Zod
  - Proteção de rotas por roles

### 🟡 Frontend Implementado
- Landing page completa com seções:
  - Hero Section
  - Benefits Section
  - Pricing Section
  - Testimonials Section
  - CTA Section
  - Footer
- Componentes UI com shadcn/ui
- Animações com Framer Motion
- Tema dark/light com next-themes

### ⚠️ Pendente de Implementação
- **Integração Stripe** (checkout, webhooks, pagamentos)
- **Páginas da aplicação** (/app/*):
  - Dashboard administrativo
  - Gestão de clientes (UI)
  - Gestão de faturas (UI)
  - Configurações de conta
- **Funcionalidades Avançadas**:
  - Geração de PDFs de faturas
  - Sistema de notificações
  - Upload de arquivos
  - Recuperação de senha
  - Verificação de email

## Estrutura do Projeto

```
lucrei/
├── client/               # Frontend React + Vite
│   ├── src/
│   │   ├── components/  # Componentes React
│   │   ├── pages/       # Páginas da aplicação
│   │   ├── hooks/       # React hooks customizados
│   │   └── lib/         # Utilitários
│   └── public/          # Assets públicos
├── server/              # Backend Express
│   ├── index.ts         # Entry point do servidor
│   ├── routes.ts        # Definição de rotas da API
│   ├── storage.ts       # Camada de acesso ao banco
│   └── db.ts            # Configuração do banco
├── shared/              # Código compartilhado
│   └── schema.ts        # Schema Drizzle + tipos TypeScript
└── package.json         # Dependências do projeto
```

## Tecnologias Utilizadas

### Backend
- **Express.js** - Framework web
- **TypeScript** - Type safety
- **Drizzle ORM** - ORM para PostgreSQL
- **Neon Database** - PostgreSQL serverless
- **Passport.js** - Autenticação
- **bcryptjs** - Hash de senhas
- **Zod** - Validação de dados

### Frontend
- **React** - UI library
- **Vite** - Build tool
- **Wouter** - Routing
- **TanStack Query** - Data fetching
- **shadcn/ui** - Componentes UI
- **Tailwind CSS** - Styling
- **Framer Motion** - Animações

### Outros
- **Stripe** - Pagamentos (integração pendente)
- **WebSockets** - Real-time (ws)

## Configuração do Ambiente

### Variáveis de Ambiente Necessárias
```bash
DATABASE_URL=postgresql://...           # URL do banco PostgreSQL
SESSION_SECRET=your-secret-key          # Segredo para sessions
STRIPE_SECRET_KEY=sk_...               # Stripe secret (quando implementar)
STRIPE_PUBLISHABLE_KEY=pk_...          # Stripe public (quando implementar)
```

### Comandos Disponíveis

```bash
# Desenvolvimento
npm run dev              # Inicia servidor de desenvolvimento

# Build
npm run build            # Build para produção
npm run start            # Inicia servidor de produção

# Banco de Dados
npm run db:push          # Sincroniza schema com o banco

# Type checking
npm run check            # Verifica tipos TypeScript
```

## API Endpoints

### Autenticação
- `POST /api/auth/register` - Registro de novo usuário
- `POST /api/auth/login` - Login
- `POST /api/auth/logout` - Logout
- `GET /api/auth/me` - Obter usuário atual

### Organizações
- `GET /api/organizations/current` - Obter organização atual
- `PUT /api/organizations/:id` - Atualizar organização

### Clientes
- `GET /api/customers` - Listar clientes
- `GET /api/customers/:id` - Obter cliente
- `POST /api/customers` - Criar cliente
- `PUT /api/customers/:id` - Atualizar cliente
- `DELETE /api/customers/:id` - Deletar cliente

### Faturas
- `GET /api/invoices` - Listar faturas
- `GET /api/invoices/:id` - Obter fatura
- `GET /api/customers/:customerId/invoices` - Faturas por cliente
- `POST /api/invoices` - Criar fatura
- `PUT /api/invoices/:id` - Atualizar fatura
- `DELETE /api/invoices/:id` - Deletar fatura

### Métricas
- `GET /api/metrics` - Obter métricas da organização

### Atividades
- `GET /api/activities` - Listar atividades recentes

## Segurança Implementada

1. **Autenticação**:
   - Sessões seguras com cookies HTTP-only
   - Hashing de senhas com bcrypt (10 rounds)
   - Middleware de autenticação em todas as rotas protegidas

2. **Autorização**:
   - Sistema de roles (OWNER, ADMIN, CUSTOMER)
   - Middleware para verificar permissões
   - Isolamento de dados por organização

3. **Validação**:
   - Validação de entrada com Zod
   - Mensagens de erro amigáveis
   - Sanitização automática

## Próximos Passos

1. **Integração Stripe** (Prioridade Alta):
   - Configurar produtos e preços no Stripe
   - Implementar checkout session
   - Webhooks para processar pagamentos
   - Gerenciar assinaturas

2. **Dashboard Administrativo**:
   - Criar páginas /app/*
   - Implementar gráficos com Recharts
   - Interface de gestão de clientes
   - Interface de gestão de faturas

3. **Funcionalidades Avançadas**:
   - Geração de PDFs
   - Sistema de notificações
   - Upload de arquivos
   - Exportação de relatórios

## Notas de Desenvolvimento

### Database Schema
O schema está totalmente definido em `shared/schema.ts`. Usa PostgreSQL com UUIDs para IDs. Todas as tabelas têm timestamps de created_at e updated_at.

### Autenticação
Utiliza Passport.js com LocalStrategy. As sessões são armazenadas em memória (development) mas devem usar store persistente em produção.

### Storage Layer
A camada `storage.ts` abstrai todas as operações de banco de dados. Implementa a interface `IStorage` com métodos tipados.

## Mudanças Recentes (04/11/2025)

- ✅ Criado schema completo do banco de dados
- ✅ Implementado sistema de autenticação completo
- ✅ Implementado CRUD de organizações, clientes e faturas
- ✅ Criado storage layer com todas as operações
- ✅ Configurado workflow de desenvolvimento
- ✅ Corrigidos erros de importação de imagens no frontend
- ✅ Aplicação rodando sem erros

## Contribuindo

Este projeto segue as convenções:
- TypeScript estrito
- ESLint para linting
- Prettier para formatação
- Commits semânticos

---

**Última atualização:** 04 de Novembro de 2025
**Status:** Backend 80% completo, Frontend landing page 100% completa, Dashboard 0% completo
